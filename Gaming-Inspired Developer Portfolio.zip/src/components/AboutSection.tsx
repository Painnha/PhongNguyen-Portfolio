import { motion } from 'motion/react';
import { GraduationCap, Code, Trophy, Users } from 'lucide-react';

const highlights = [
  {
    icon: GraduationCap,
    text: "Graduated from IUH with strong foundation in Computer Science",
  },
  {
    icon: Code,
    text: "Interned at FSoft, working on enterprise-level applications",
  },
  {
    icon: Trophy,
    text: "Built AI-powered student admission recommendation system",
  },
  {
    icon: Users,
    text: "Led esports community with 500+ members in Liên Quân Mobile",
  },
];

export function AboutSection() {
  return (
    <section id="about" className="py-20 px-4 bg-[#121212] relative overflow-hidden">
      {/* Background Accent */}
      <div className="absolute top-0 right-0 w-96 h-96 bg-[#FF6B00]/5 rounded-full blur-3xl" />
      
      <div className="container mx-auto max-w-6xl relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
        >
          <h2 
            className="mb-12 text-center"
            style={{ fontSize: 'clamp(36px, 5vw, 48px)' }}
          >
            About <span className="text-[#FF6B00]">Me</span>
          </h2>
        </motion.div>

        <div className="grid md:grid-cols-2 gap-12 items-center">
          {/* Left: Image/Infographic */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="relative"
          >
            <div className="relative group">
              <div className="absolute -inset-1 bg-gradient-to-r from-[#FF6B00] to-[#FFA500] rounded-lg blur opacity-25 group-hover:opacity-50 transition duration-500" />
              <div className="relative aspect-square rounded-lg overflow-hidden border-2 border-[#FF6B00]/20">
                <img
                  src="https://images.unsplash.com/photo-1593720213681-e9a8778330a7?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx3ZWIlMjBkZXZlbG9wbWVudCUyMGNvZGluZ3xlbnwxfHx8fDE3NjE3OTYzMjV8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
                  alt="Developer"
                  className="w-full h-full object-cover"
                />
              </div>
            </div>
          </motion.div>

          {/* Right: Text Content */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.3 }}
          >
            <h3 className="mb-6 text-[#FF6B00]" style={{ fontSize: '24px' }}>
              My Journey
            </h3>
            <p className="mb-6 text-[#B0B0B0] leading-relaxed">
              My journey in tech started at Industrial University of Ho Chi Minh City (IUH), where I discovered 
              my passion for building innovative solutions. During my internship at FSoft, I gained hands-on 
              experience developing enterprise applications and working with cutting-edge technologies.
            </p>
            <p className="mb-8 text-[#B0B0B0] leading-relaxed">
              One of my proudest achievements is creating an AI-powered student admission system that uses 
              machine learning to recommend optimal academic paths. Beyond coding, I'm passionate about 
              esports and community building, having led a thriving Liên Quân Mobile community that taught 
              me valuable lessons in teamwork and organization.
            </p>

            {/* Key Highlights */}
            <div className="space-y-4">
              {highlights.map((item, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, x: -20 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: 0.4 + index * 0.1 }}
                  className="flex items-start gap-3 group"
                >
                  <div className="mt-1 p-2 bg-[#FF6B00]/10 rounded-lg group-hover:bg-[#FF6B00]/20 transition-colors">
                    <item.icon className="w-5 h-5 text-[#FF6B00]" />
                  </div>
                  <p className="text-[#B0B0B0] flex-1">{item.text}</p>
                </motion.div>
              ))}
            </div>

            <motion.div
              initial={{ opacity: 0 }}
              whileInView={{ opacity: 1 }}
              viewport={{ once: true }}
              transition={{ delay: 0.8 }}
              className="mt-8 p-4 bg-[#1E1E1E] border border-[#FF6B00]/20 rounded-lg"
            >
              <p className="text-[#FF6B00]">
                💼 Currently open to full-stack developer roles with AI/ML focus
              </p>
            </motion.div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
