import { motion } from 'motion/react';
import { 
  Code2, 
  Database, 
  GitBranch, 
  Smartphone,
  Cloud,
  Box,
  Wrench,
  Users,
  Trophy,
  Target,
  MessageSquare
} from 'lucide-react';
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from './ui/tooltip';

// Tech skills with projects/context
const techSkills = [
  // Frontend
  {
    name: 'React',
    icon: Code2,
    description: 'Built AI Student Admission System, Ban-Pick Tool',
    color: '#61DAFB',
    category: 'frontend',
    proficiency: 'high', // high, medium for sizing
  },
  {
    name: 'Next.js',
    icon: Code2,
    description: 'Used in Liên Quân Ban-Pick Tool for SSR',
    color: '#FFFFFF',
    category: 'frontend',
    proficiency: 'high',
  },
  {
    name: 'TypeScript',
    icon: Code2,
    description: 'Primary language for modern frontend projects',
    color: '#3178C6',
    category: 'frontend',
    proficiency: 'high',
  },
  {
    name: 'Tailwind CSS',
    icon: Code2,
    description: 'Styling framework for all recent projects',
    color: '#06B6D4',
    category: 'frontend',
    proficiency: 'high',
  },
  
  // Backend
  {
    name: 'Java',
    icon: Code2,
    description: 'FSoft internship, E-Commerce Platform with Spring Boot',
    color: '#ED8B00',
    category: 'backend',
    proficiency: 'high',
  },
  {
    name: 'Node.js',
    icon: Code2,
    description: 'Event Manager backend, REST APIs',
    color: '#339933',
    category: 'backend',
    proficiency: 'medium',
  },
  {
    name: 'Python',
    icon: Code2,
    description: 'AI/ML projects, TensorFlow model training',
    color: '#3776AB',
    category: 'backend',
    proficiency: 'high',
  },
  {
    name: 'SQL',
    icon: Database,
    description: 'MySQL, PostgreSQL for relational databases',
    color: '#4479A1',
    category: 'backend',
    proficiency: 'high',
  },
  {
    name: 'MongoDB',
    icon: Database,
    description: 'NoSQL database for Ban-Pick Tool',
    color: '#47A248',
    category: 'backend',
    proficiency: 'medium',
  },
  
  // AI & Tools
  {
    name: 'TensorFlow',
    icon: Code2,
    description: 'Trained ML model for Student Admission System (85% accuracy)',
    color: '#FF6F00',
    category: 'ai',
    proficiency: 'medium',
  },
  {
    name: 'Git/GitHub',
    icon: GitBranch,
    description: 'Version control for all projects, collaborative workflows',
    color: '#F05032',
    category: 'tools',
    proficiency: 'high',
  },
  {
    name: 'Docker',
    icon: Box,
    description: 'Containerization for deployment environments',
    color: '#2496ED',
    category: 'tools',
    proficiency: 'medium',
  },
  {
    name: 'Figma',
    icon: Smartphone,
    description: 'UI/UX design and prototyping',
    color: '#F24E1E',
    category: 'tools',
    proficiency: 'medium',
  },
  {
    name: 'Azure',
    icon: Cloud,
    description: 'Cloud deployment and services',
    color: '#0078D4',
    category: 'tools',
    proficiency: 'medium',
  },
];

// Soft skills
const softSkills = [
  {
    name: 'Leadership',
    icon: Trophy,
    description: 'Led 500+ member Liên Quân community',
    color: '#FF6B00',
  },
  {
    name: 'Event Management',
    icon: Target,
    description: 'Organized esports tournaments and tech workshops',
    color: '#FFA500',
  },
  {
    name: 'Teamwork',
    icon: Users,
    description: 'Collaborative projects at FSoft and university',
    color: '#FF6B00',
  },
  {
    name: 'Communication',
    icon: MessageSquare,
    description: 'Presenting technical concepts to diverse audiences',
    color: '#FFA500',
  },
];

export function SkillsSection() {
  return (
    <section id="skills" className="py-20 px-4 bg-gradient-to-b from-[#121212] to-[#1E1E1E] relative overflow-hidden">
      {/* Background Accents */}
      <div className="absolute top-1/4 left-0 w-96 h-96 bg-[#FF6B00]/5 rounded-full blur-3xl" />
      <div className="absolute bottom-1/4 right-0 w-96 h-96 bg-[#FFA500]/5 rounded-full blur-3xl" />
      
      <div className="container mx-auto max-w-6xl relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
        >
          <h2 
            className="mb-4 text-center"
            style={{ fontSize: 'clamp(36px, 5vw, 48px)' }}
          >
            Tech <span className="text-[#FF6B00]">Stack</span>
          </h2>
          <p className="text-center text-[#B0B0B0] mb-16 max-w-2xl mx-auto">
            Technologies and tools I've used in real projects. Hover for context and experience.
          </p>
        </motion.div>

        {/* Technical Skills - Icon Grid */}
        <TooltipProvider delayDuration={100}>
          <motion.div
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.2 }}
          >
            <h3 className="text-white mb-8 text-center" style={{ fontSize: '24px' }}>
              💻 Technical Skills
            </h3>
            <div className="flex flex-wrap justify-center gap-6 mb-16">
              {techSkills.map((skill, index) => (
                <motion.div
                  key={skill.name}
                  initial={{ opacity: 0, scale: 0.8 }}
                  whileInView={{ opacity: 1, scale: 1 }}
                  viewport={{ once: true }}
                  transition={{ delay: index * 0.03, duration: 0.3 }}
                >
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <motion.div
                        whileHover={{ 
                          scale: 1.1,
                          y: -5,
                        }}
                        className={`
                          ${skill.proficiency === 'high' ? 'w-20 h-20' : 'w-16 h-16'}
                          bg-[#1E1E1E] border-2 border-[#2a2a2a] rounded-xl 
                          flex flex-col items-center justify-center gap-1 
                          cursor-pointer transition-all duration-300
                          hover:border-[#FF6B00] hover:shadow-lg hover:shadow-[#FF6B00]/20
                          group relative overflow-hidden
                        `}
                      >
                        {/* Glow effect on hover */}
                        <div 
                          className="absolute inset-0 bg-gradient-to-br opacity-0 group-hover:opacity-10 transition-opacity"
                          style={{ 
                            backgroundImage: `linear-gradient(135deg, ${skill.color}, transparent)` 
                          }}
                        />
                        
                        <skill.icon 
                          className="transition-colors duration-300 group-hover:drop-shadow-lg"
                          style={{ 
                            width: skill.proficiency === 'high' ? '32px' : '24px',
                            height: skill.proficiency === 'high' ? '32px' : '24px',
                            color: skill.color,
                          }} 
                        />
                        <span 
                          className="text-[#B0B0B0] group-hover:text-white transition-colors text-center"
                          style={{ fontSize: skill.proficiency === 'high' ? '10px' : '9px' }}
                        >
                          {skill.name}
                        </span>
                      </motion.div>
                    </TooltipTrigger>
                    <TooltipContent 
                      className="bg-[#1E1E1E] border-[#FF6B00] text-white max-w-xs"
                      side="top"
                    >
                      <p className="font-medium mb-1">{skill.name}</p>
                      <p className="text-[#B0B0B0]" style={{ fontSize: '14px' }}>
                        {skill.description}
                      </p>
                    </TooltipContent>
                  </Tooltip>
                </motion.div>
              ))}
            </div>
          </motion.div>

          {/* Soft Skills */}
          <motion.div
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.4 }}
          >
            <h3 className="text-white mb-8 text-center" style={{ fontSize: '24px' }}>
              🤝 Soft Skills
            </h3>
            <div className="flex flex-wrap justify-center gap-4">
              {softSkills.map((skill, index) => (
                <motion.div
                  key={skill.name}
                  initial={{ opacity: 0, x: -20 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: index * 0.1 }}
                >
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <motion.div
                        whileHover={{ scale: 1.05 }}
                        className="px-6 py-4 bg-[#1E1E1E] border border-[#2a2a2a] rounded-lg 
                          hover:border-[#FF6B00] transition-all duration-300 cursor-pointer
                          hover:shadow-lg hover:shadow-[#FF6B00]/10 group flex items-center gap-3"
                      >
                        <div className="p-2 bg-[#FF6B00]/10 rounded-lg group-hover:bg-[#FF6B00]/20 transition-colors">
                          <skill.icon 
                            className="w-5 h-5" 
                            style={{ color: skill.color }}
                          />
                        </div>
                        <span className="text-[#B0B0B0] group-hover:text-white transition-colors">
                          {skill.name}
                        </span>
                      </motion.div>
                    </TooltipTrigger>
                    <TooltipContent 
                      className="bg-[#1E1E1E] border-[#FF6B00] text-white max-w-xs"
                      side="top"
                    >
                      <p className="font-medium mb-1">{skill.name}</p>
                      <p className="text-[#B0B0B0]" style={{ fontSize: '14px' }}>
                        {skill.description}
                      </p>
                    </TooltipContent>
                  </Tooltip>
                </motion.div>
              ))}
            </div>
          </motion.div>
        </TooltipProvider>

        {/* Additional Info */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: 0.6 }}
          className="mt-16 text-center"
        >
          <div className="inline-flex items-center gap-2 px-6 py-3 bg-[#FF6B00]/10 border border-[#FF6B00]/30 rounded-full">
            <Wrench className="w-4 h-4 text-[#FF6B00]" />
            <p className="text-[#B0B0B0]">
              Always learning and exploring new technologies
            </p>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
