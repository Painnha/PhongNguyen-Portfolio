import { motion } from 'motion/react';
import { Mail, Linkedin, Github, Facebook, ArrowUp, Send } from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Textarea } from './ui/textarea';
import { useState } from 'react';
import { toast } from 'sonner@2.0.3';

const socialLinks = [
  { icon: Linkedin, label: 'LinkedIn', href: '#', color: '#0077B5' },
  { icon: Github, label: 'GitHub', href: '#', color: '#FFFFFF' },
  { icon: Facebook, label: 'Facebook', href: '#', color: '#1877F2' },
  { icon: Mail, label: 'Email', href: 'mailto:your.email@example.com', color: '#FF6B00' },
];

export function ContactSection() {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    message: '',
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    toast.success('Message sent! I\'ll get back to you soon.');
    setFormData({ name: '', email: '', message: '' });
  };

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <section id="contact" className="py-20 px-4 bg-gradient-to-b from-[#1E1E1E] to-[#121212] relative overflow-hidden">
      {/* Background Accents */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-96 h-96 bg-[#FF6B00]/10 rounded-full blur-3xl" />
      
      <div className="container mx-auto max-w-4xl relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
        >
          <h2 
            className="mb-4 text-center"
            style={{ fontSize: 'clamp(36px, 5vw, 48px)' }}
          >
            Let's <span className="text-[#FF6B00]">Connect</span>
          </h2>
          <p className="text-center text-[#B0B0B0] mb-12 max-w-2xl mx-auto">
            I'm always open to discussing new opportunities, collaborations, or just having a chat about tech and gaming!
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 gap-8 mb-12">
          {/* Contact Form */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <form onSubmit={handleSubmit} className="space-y-6">
              <div>
                <label htmlFor="name" className="block text-white mb-2">
                  Name
                </label>
                <Input
                  id="name"
                  type="text"
                  placeholder="Your name"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  className="bg-[#1E1E1E] border-[#2a2a2a] text-white focus:border-[#FF6B00] focus:ring-[#FF6B00]"
                  required
                />
              </div>
              
              <div>
                <label htmlFor="email" className="block text-white mb-2">
                  Email
                </label>
                <Input
                  id="email"
                  type="email"
                  placeholder="your.email@example.com"
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  className="bg-[#1E1E1E] border-[#2a2a2a] text-white focus:border-[#FF6B00] focus:ring-[#FF6B00]"
                  required
                />
              </div>
              
              <div>
                <label htmlFor="message" className="block text-white mb-2">
                  Message
                </label>
                <Textarea
                  id="message"
                  placeholder="Tell me about your project or opportunity..."
                  value={formData.message}
                  onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                  className="bg-[#1E1E1E] border-[#2a2a2a] text-white focus:border-[#FF6B00] focus:ring-[#FF6B00] min-h-[150px]"
                  required
                />
              </div>

              <Button
                type="submit"
                className="w-full bg-[#FF6B00] hover:bg-[#FFA500] text-white transition-all duration-300 hover:scale-[1.02] hover:shadow-lg hover:shadow-[#FF6B00]/50"
              >
                <Send className="mr-2 h-4 w-4" />
                Send Message
              </Button>
            </form>
          </motion.div>

          {/* Social Links & Info */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="flex flex-col justify-center"
          >
            <div className="p-8 bg-[#1E1E1E] border border-[#2a2a2a] rounded-lg">
              <h3 className="mb-6 text-white" style={{ fontSize: '24px' }}>
                Get in Touch
              </h3>
              <p className="text-[#B0B0B0] mb-8">
                Feel free to reach out through any of these platforms. I usually respond within 24 hours!
              </p>

              {/* Social Icons */}
              <div className="space-y-4">
                {socialLinks.map((social, index) => (
                  <motion.a
                    key={social.label}
                    href={social.href}
                    target="_blank"
                    rel="noopener noreferrer"
                    initial={{ opacity: 0, x: -20 }}
                    whileInView={{ opacity: 1, x: 0 }}
                    viewport={{ once: true }}
                    transition={{ delay: index * 0.1 }}
                    className="flex items-center gap-4 p-3 rounded-lg bg-[#121212] hover:bg-[#2a2a2a] transition-all duration-300 group"
                  >
                    <div className="p-2 bg-[#FF6B00]/10 rounded-lg group-hover:bg-[#FF6B00]/20 transition-colors">
                      <social.icon className="w-5 h-5" style={{ color: social.color }} />
                    </div>
                    <span className="text-[#B0B0B0] group-hover:text-white transition-colors">
                      {social.label}
                    </span>
                  </motion.a>
                ))}
              </div>

              {/* Additional Info */}
              <div className="mt-8 pt-6 border-t border-[#2a2a2a]">
                <p className="text-[#B0B0B0]" style={{ fontSize: '14px' }}>
                  📍 Ho Chi Minh City, Vietnam
                </p>
                <p className="text-[#B0B0B0] mt-2" style={{ fontSize: '14px' }}>
                  ⏰ Available for freelance & full-time
                </p>
              </div>
            </div>
          </motion.div>
        </div>

        {/* Footer */}
        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ delay: 0.4 }}
          className="text-center pt-8 border-t border-[#2a2a2a]"
        >
          <p className="text-[#B0B0B0] mb-4">
            © 2025 Your Name. Built with React, Tailwind CSS, and Motion
          </p>
          <p className="text-[#B0B0B0]/60" style={{ fontSize: '14px' }}>
            Designed & Developed with 💙 for innovation and esports
          </p>
        </motion.div>
      </div>

      {/* Back to Top Button */}
      <motion.button
        onClick={scrollToTop}
        initial={{ opacity: 0, scale: 0 }}
        whileInView={{ opacity: 1, scale: 1 }}
        viewport={{ once: true }}
        className="fixed bottom-8 right-8 p-4 bg-[#FF6B00] hover:bg-[#FFA500] text-white rounded-full shadow-lg hover:shadow-xl hover:shadow-[#FF6B00]/50 transition-all duration-300 z-50 hover:scale-110"
        whileHover={{ y: -5 }}
      >
        <ArrowUp className="w-6 h-6" />
      </motion.button>
    </section>
  );
}
