import { motion } from 'motion/react';
import { ExternalLink, Github, Play } from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Button } from './ui/button';

const projects = [
  {
    title: 'AI Student Admission System',
    description: 'Intelligent recommendation system using machine learning to suggest optimal academic paths for university applicants. Trained on historical admission data with 85% accuracy.',
    image: 'https://images.unsplash.com/photo-1757310998648-f8aaa5572e8e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxBSSUyMHRlY2hub2xvZ3klMjBpbnRlcmZhY2V8ZW58MXx8fHwxNzYxNzU0Mjc2fDA&ixlib=rb-4.1.0&q=80&w=1080',
    tags: ['Python', 'TensorFlow', 'React', 'FastAPI'],
    category: 'AI',
  },
  {
    title: 'Liên Quân Ban-Pick Tool',
    description: 'Real-time draft analysis tool for Liên Quân Mobile esports teams. Features hero counters, win rate statistics, and team composition suggestions based on meta analysis.',
    image: 'https://images.unsplash.com/photo-1759709690954-8cd33574f022?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxlc3BvcnRzJTIwZ2FtaW5nJTIwdGVhbXxlbnwxfHx8fDE3NjE4MTM4NzB8MA&ixlib=rb-4.1.0&q=80&w=1080',
    tags: ['Next.js', 'TypeScript', 'MongoDB', 'Tailwind'],
    category: 'Full-Stack',
  },
  {
    title: 'E-Commerce Platform',
    description: 'Full-featured online shopping platform with product management, shopping cart, payment integration, and admin dashboard. Built during FSoft internship.',
    image: 'https://images.unsplash.com/photo-1593720213681-e9a8778330a7?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx3ZWIlMjBkZXZlbG9wbWVudCUyMGNvZGluZ3xlbnwxfHx8fDE3NjE3OTYzMjV8MA&ixlib=rb-4.1.0&q=80&w=1080',
    tags: ['Java', 'Spring Boot', 'MySQL', 'React'],
    category: 'Backend',
  },
  {
    title: 'Community Event Manager',
    description: 'Web application for managing esports tournaments and community events. Includes bracket generation, team registration, and live score updates used by 500+ members.',
    image: 'https://images.unsplash.com/photo-1719400471588-575b23e27bd7?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwcm9mZXNzaW9uYWwlMjBkZXZlbG9wZXIlMjB3b3Jrc3BhY2V8ZW58MXx8fHwxNzYxNzExODQ3fDA&ixlib=rb-4.1.0&q=80&w=1080',
    tags: ['Node.js', 'Express', 'Socket.io', 'Vue.js'],
    category: 'Full-Stack',
  },
];

export function ProjectsSection() {
  return (
    <section id="projects" className="py-20 px-4 bg-[#121212] relative overflow-hidden">
      {/* Background Grid Pattern */}
      <div className="absolute inset-0 opacity-10">
        <div className="absolute inset-0" style={{
          backgroundImage: `linear-gradient(#FF6B00 1px, transparent 1px), linear-gradient(90deg, #FF6B00 1px, transparent 1px)`,
          backgroundSize: '50px 50px',
        }} />
      </div>
      
      <div className="container mx-auto max-w-6xl relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
        >
          <h2 
            className="mb-4 text-center"
            style={{ fontSize: 'clamp(36px, 5vw, 48px)' }}
          >
            Featured <span className="text-[#FF6B00]">Projects</span>
          </h2>
          <p className="text-center text-[#B0B0B0] mb-12 max-w-2xl mx-auto">
            A showcase of my recent work spanning full-stack development, AI/ML, and community-focused applications.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {projects.map((project, index) => (
            <motion.div
              key={project.title}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1, duration: 0.5 }}
              className="group"
            >
              <Card className="h-full bg-[#1E1E1E] border-[#2a2a2a] hover:border-[#FF6B00]/50 transition-all duration-300 overflow-hidden hover:shadow-xl hover:shadow-[#FF6B00]/20 hover:scale-[1.02]">
                {/* Project Image */}
                <div className="relative aspect-video overflow-hidden">
                  <img
                    src={project.image}
                    alt={project.title}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-[#1E1E1E] to-transparent opacity-60" />
                  
                  {/* Overlay Actions */}
                  <div className="absolute inset-0 flex items-center justify-center gap-3 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                    <Button
                      size="sm"
                      className="bg-[#FF6B00] hover:bg-[#FFA500] text-white"
                    >
                      <Github className="w-4 h-4 mr-2" />
                      Code
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      className="border-white text-white hover:bg-white hover:text-[#121212]"
                    >
                      <ExternalLink className="w-4 h-4 mr-2" />
                      Demo
                    </Button>
                  </div>
                </div>

                <CardHeader>
                  <div className="flex items-start justify-between mb-2">
                    <CardTitle className="text-white group-hover:text-[#FF6B00] transition-colors">
                      {project.title}
                    </CardTitle>
                  </div>
                  <CardDescription className="text-[#B0B0B0]">
                    {project.description}
                  </CardDescription>
                </CardHeader>

                <CardContent>
                  {/* Tech Stack Tags */}
                  <div className="flex flex-wrap gap-2">
                    {project.tags.map((tag) => (
                      <Badge
                        key={tag}
                        variant="secondary"
                        className="bg-[#FF6B00]/10 text-[#FF6B00] border border-[#FF6B00]/20 hover:bg-[#FF6B00]/20"
                      >
                        {tag}
                      </Badge>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>

        {/* View More */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: 0.5 }}
          className="mt-12 text-center"
        >
          <Button
            variant="outline"
            className="border-[#FF6B00] text-[#FF6B00] hover:bg-[#FF6B00] hover:text-white px-8 transition-all duration-300"
          >
            <Github className="mr-2 h-5 w-5" />
            View All Projects on GitHub
          </Button>
        </motion.div>
      </div>
    </section>
  );
}
