
  # Gaming-Inspired Developer Portfolio

  This is a code bundle for Gaming-Inspired Developer Portfolio. The original project is available at https://www.figma.com/design/33bSG7UD0nzMSiNPGOAZQm/Gaming-Inspired-Developer-Portfolio.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  